import Nav from '@/components/Nav';
import QuizGame from '@/components/QuizGame';

export default function QuizPage() {
  return (
    <div className="container">
      <Nav />
      <QuizGame />
    </div>
  );
}
