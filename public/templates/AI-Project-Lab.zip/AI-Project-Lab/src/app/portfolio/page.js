import Nav from '@/components/Nav';
import Portfolio from '@/components/Portfolio';

export default function PortfolioPage() {
  return (
    <div className="container">
      <Nav />
      <Portfolio />
    </div>
  );
}
