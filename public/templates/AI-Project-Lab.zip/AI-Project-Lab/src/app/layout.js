import './styles/globals.css';

export const metadata = {
  title: 'AI Project Lab',
  description: 'Kids can build AI projects step-by-step.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="zh">
      <body>
        {children}
      </body>
    </html>
  );
}
