import { NextResponse } from 'next/server';

export async function POST(req) {
  const key = process.env.OPENAI_API_KEY;
  if (!key) {
    return NextResponse.json({ error: '缺少 OPENAI_API_KEY（已自动使用本地题库）。' }, { status: 400 });
  }

  let body = {};
  try { body = await req.json(); } catch {}
  const level = body.level || '初中';
  const topic = body.topic || '编程逻辑';

  const system = '你是出题老师。必须只输出 JSON，不要任何多余文字。';
  const user = `请出一道适合${level}的${topic}单选题。
要求：
1) 必须严格返回 JSON：{"question":"","options":["","","",""],"answer":""}
2) options 必须正好 4 个
3) answer 必须和 options 里某一个完全一致
4) 题目要有趣，贴近学生生活，难度适中`;

  try {
    const resp = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${key}`
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
        temperature: 0.7,
        messages: [
          { role: 'system', content: system },
          { role: 'user', content: user }
        ]
      })
    });

    if (!resp.ok) {
      const t = await resp.text();
      return NextResponse.json({ error: `AI 请求失败：${resp.status} ${t.slice(0, 180)}` }, { status: 500 });
    }

    const data = await resp.json();
    const content = data?.choices?.[0]?.message?.content;
    if (!content) return NextResponse.json({ error: 'AI 未返回内容' }, { status: 500 });

    // 尝试提取 JSON
    let jsonText = content.trim();
    const firstBrace = jsonText.indexOf('{');
    const lastBrace = jsonText.lastIndexOf('}');
    if (firstBrace !== -1 && lastBrace !== -1) {
      jsonText = jsonText.slice(firstBrace, lastBrace + 1);
    }
    const q = JSON.parse(jsonText);
    return NextResponse.json(q);
  } catch (e) {
    return NextResponse.json({ error: `AI 解析失败：${String(e).slice(0, 200)}` }, { status: 500 });
  }
}
