import Nav from '@/components/Nav';

export default function StartPage() {
  return (
    <div className="container">
      <Nav />
      <div className="card">
        <h1 className="h1">新手从这里开始（0基础也行）</h1>
        <p className="small">你只需要会：复制粘贴、保存文件、在终端运行命令。不会也没关系，按步骤走就行。</p>
      </div>

      <div className="card" style={{marginTop:12}}>
        <h2 className="h2">1) 3 分钟跑起来</h2>
        <ol className="small">
          <li>安装 Node.js（推荐 18+）</li>
          <li>打开终端，进入项目文件夹</li>
          <li>运行：<code>npm install</code></li>
          <li>运行：<code>npm run dev</code></li>
          <li>打开浏览器：<code>http://localhost:3000</code></li>
        </ol>
      </div>

      <div className="card" style={{marginTop:12}}>
        <h2 className="h2">2) 改哪里（最重要）</h2>
        <ul className="small">
          <li><b>改题库：</b>只改 <code>src/data/questionBank.js</code></li>
          <li><b>加功能：</b>优先放 <code>src/lib/</code>（逻辑）或 <code>src/components/</code>（界面）</li>
          <li><b>不要乱改：</b><code>src/app/</code> 里是页面拼装区，尽量不写复杂逻辑</li>
        </ul>
      </div>

      <div className="card" style={{marginTop:12}}>
        <h2 className="h2">3) 你可以做的 3 个“立刻变强”任务</h2>
        <ol className="small">
          <li>在题库里新增 5 道题（保证每题 options 恰好 4 个，answer 必须在 options 里）</li>
          <li>把倒计时从 10 秒改成 15 秒（答题页右侧设置里改）</li>
          <li>给答题页加一个“错题本”（把答错的题存到 localStorage，再做一个页面展示）</li>
        </ol>
      </div>

      <div className="card" style={{marginTop:12}}>
        <h2 className="h2">4)（可选）开启 AI 出题</h2>
        <p className="small">
          默认不需要 Key 就能玩（本地题库）。如果你有 OpenAI Key：
        </p>
        <ol className="small">
          <li>复制 <code>.env.example</code> 为 <code>.env.local</code></li>
          <li>填入 <code>OPENAI_API_KEY</code></li>
          <li>重启 <code>npm run dev</code></li>
        </ol>
        <p className="small">然后在答题页右侧把“AI 出题”打开即可。</p>
      </div>
    </div>
  );
}
