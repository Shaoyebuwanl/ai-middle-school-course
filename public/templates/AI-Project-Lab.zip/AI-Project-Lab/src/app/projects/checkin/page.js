import Nav from '@/components/Nav';
import CheckIn from '@/components/CheckIn';

export default function CheckInPage() {
  return (
    <div className="container">
      <Nav />
      <CheckIn />
    </div>
  );
}
