import Nav from '@/components/Nav';
import PromptCoach from '@/components/PromptCoach';

export default function AssistantPage() {
  return (
    <div className="container">
      <Nav />
      <PromptCoach />
    </div>
  );
}
