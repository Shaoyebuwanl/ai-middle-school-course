import Nav from '@/components/Nav';
import Link from 'next/link';

const projects = [
  { id: 'quiz', title: '项目1：答题小游戏（已完成）', desc: '倒计时 + 得分 + 题库 + AI 出题（可选）', href: '/quiz' },
  { id: 'checkin', title: '项目2：学习打卡（可扩展）', desc: '每天打卡、统计天数、生成小徽章（模板已给）', href: '/projects/checkin' },
  { id: 'assistant', title: '项目3：AI 学习助手（可扩展）', desc: '把问题写清楚，让 AI 给步骤（模板已给）', href: '/projects/assistant' }
];

export default function ProjectsPage() {
  return (
    <div className="container">
      <Nav />
      <div className="card">
        <h1 className="h1">项目列表</h1>
        <p className="small">每个项目都可以独立完成，并写进作品集。</p>
      </div>

      <div className="row" style={{marginTop:12, flexDirection:'column'}}>
        {projects.map(p => (
          <Link key={p.id} href={p.href} className="card" style={{display:'block'}}>
            <h2 className="h2">{p.title}</h2>
            <p className="small">{p.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
