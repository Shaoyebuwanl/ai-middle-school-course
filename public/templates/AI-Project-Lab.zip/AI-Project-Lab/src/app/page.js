import Link from 'next/link';
import Nav from '@/components/Nav';

export default function Home() {
  return (
    <div className="container">
      <Nav />
      <div className="card">
        <h1 className="h1">AI Project Lab</h1>
        <p className="small">面向中小学生：用 AI 做项目、改 Bug、做作品集。</p>
        <div className="row" style={{ marginTop: 12 }}>
          <Link className="btn btnPrimary" href="/quiz">开始答题游戏</Link>
          <Link className="btn" href="/projects">项目列表</Link>
          <Link className="btn" href="/portfolio">作品集</Link>
          <Link className="btn btnGhost" href="/start">新手从这里开始</Link>
        </div>
      </div>
    </div>
  );
}
