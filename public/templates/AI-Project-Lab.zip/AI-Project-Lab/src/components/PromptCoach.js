'use client';

import { useMemo, useState } from 'react';

export default function PromptCoach() {
  const [goal, setGoal] = useState('帮我把一道数学题讲明白');
  const [audience, setAudience] = useState('四年级');
  const [format, setFormat] = useState('用 3 步讲解 + 1 个例子');
  const [constraints, setConstraints] = useState('不用复杂词；每步不超过 2 句话');

  const prompt = useMemo(() => {
    return `你是一个耐心的老师。\n\n【目标】${goal}\n【对象】${audience}\n【输出格式】${format}\n【限制】${constraints}\n\n请给出结果，并在最后加一句“我下一步应该做什么？”来引导我继续迭代。`;
  }, [goal, audience, format, constraints]);

  return (
    <div className="card">
      <h1 className="h1">项目3：AI 学习助手（Prompt 教练）</h1>
      <p className="small">这个项目教你：如何把问题说清楚，让 AI 给你更好答案（这就是 vibe coding 的基础）。</p>

      <div className="row" style={{marginTop:12}}>
        <div style={{flex:1, minWidth:280}}>
          <label className="small">目标</label>
          <input className="btn" value={goal} onChange={e => setGoal(e.target.value)} style={{width:'100%'}} />
        </div>
        <div style={{flex:1, minWidth:180}}>
          <label className="small">对象</label>
          <input className="btn" value={audience} onChange={e => setAudience(e.target.value)} style={{width:'100%'}} />
        </div>
      </div>

      <div className="row" style={{marginTop:12}}>
        <div style={{flex:1, minWidth:280}}>
          <label className="small">输出格式</label>
          <input className="btn" value={format} onChange={e => setFormat(e.target.value)} style={{width:'100%'}} />
        </div>
        <div style={{flex:1, minWidth:280}}>
          <label className="small">限制</label>
          <input className="btn" value={constraints} onChange={e => setConstraints(e.target.value)} style={{width:'100%'}} />
        </div>
      </div>

      <div style={{marginTop:14}}>
        <h2 className="h2">生成的“好提示词”</h2>
        <pre className="card" style={{whiteSpace:'pre-wrap', margin:0}}>{prompt}</pre>
      </div>

      <div style={{marginTop:14}}>
        <h2 className="h2">挑战任务</h2>
        <ul className="small">
          <li>把同一个目标，分别写成“短提示词”和“长提示词”，比较效果。</li>
          <li>加一个字段：<b>评估标准</b>（比如“答案必须包含 1 个生活例子”）。</li>
          <li>让 AI 给你 3 个不同难度版本（基础 / 提升 / 拓展）。</li>
        </ul>
      </div>
    </div>
  );
}
