'use client';

import { useCallback, useMemo, useState } from 'react';
import { questionBank, topics, levels } from '@/data/questionBank';
import { pickFromBank, shuffle, validateQuestion } from '@/lib/quizUtils';
import { useCountdown } from '@/lib/useCountdown';

const DEFAULT_TIME = 10;

export default function QuizGame() {
  const [level, setLevel] = useState('小学');
  const [topic, setTopic] = useState('AI思维');
  const [secondsPerQ, setSecondsPerQ] = useState(DEFAULT_TIME);
  const [aiMode, setAiMode] = useState(false);

  const [q, setQ] = useState(() => makeLocalQuestion(level, topic));
  const [options, setOptions] = useState(() => shuffle(q.options));
  const [selected, setSelected] = useState(null);
  const [locked, setLocked] = useState(false);
  const [score, setScore] = useState(0);
  const [total, setTotal] = useState(0);
  const [running, setRunning] = useState(true);
  const [message, setMessage] = useState('');

  const timeLeft = useCountdown(secondsPerQ, running && !locked, () => {
    setMessage('时间到！点击“下一题”继续。');
    setLocked(true);
    setTotal(t => t + 1);
  });

  const flash = timeLeft <= 3 && running && !locked;

  const stateLabel = useMemo(() => {
    if (locked && selected === q.answer) return '答对啦 ✅';
    if (locked && selected && selected !== q.answer) return '答错了 ❌';
    if (locked && !selected) return '超时 ⏰';
    return '答题中';
  }, [locked, selected, q.answer]);

  function makeLocalQuestion(lv, tp) {
    const picked = pickFromBank(questionBank, { level: lv, topic: tp });
    // 深拷贝以防被改
    return JSON.parse(JSON.stringify(picked));
  }

  const loadNext = useCallback(async () => {
    setMessage('');
    setSelected(null);
    setLocked(false);

    // 先本地
    let nextQ = makeLocalQuestion(level, topic);

    // 可选 AI
    if (aiMode) {
      try {
        const resp = await fetch('/api/generate-question', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ level, topic })
        });
        if (resp.ok) {
          const data = await resp.json();
          if (validateQuestion(data)) {
            nextQ = data;
          } else {
            setMessage('AI 返回格式不对，已自动切回本地题库。');
          }
        } else {
          const err = await resp.json().catch(() => ({}));
          setMessage(err?.error || 'AI 模式暂不可用，已自动切回本地题库。');
        }
      } catch {
        setMessage('AI 模式暂不可用，已自动切回本地题库。');
      }
    }

    setQ(nextQ);
    setOptions(shuffle(nextQ.options || []));
    setRunning(true);
  }, [aiMode, level, topic]);

  function choose(opt) {
    if (locked) return;
    setSelected(opt);
    setLocked(true);
    setTotal(t => t + 1);
    if (opt === q.answer) setScore(s => s + 1);
  }

  function restart() {
    setScore(0);
    setTotal(0);
    setMessage('');
    const first = makeLocalQuestion(level, topic);
    setQ(first);
    setOptions(shuffle(first.options));
    setSelected(null);
    setLocked(false);
    setRunning(true);
  }

  function applyFilters() {
    // 应用筛选后立即换题
    const next = makeLocalQuestion(level, topic);
    setQ(next);
    setOptions(shuffle(next.options));
    setSelected(null);
    setLocked(false);
    setMessage('');
    setRunning(true);
    setTotal(0);
    setScore(0);
  }

  return (
    <div className="grid" style={{marginTop:12}}>
      <div className="card">
        <div className="row" style={{justifyContent:'space-between'}}>
          <div>
            <div className="badge">状态：{stateLabel}</div>
          </div>
          <div className="row">
            <div className={`timer ${flash ? 'flash' : ''}`}>⏳ {timeLeft}s</div>
          </div>
        </div>

        <h2 className="h2" style={{marginTop:12}}>{q.question}</h2>
        {q.hint ? <p className="small">提示：{q.hint}</p> : null}

        <div className="row" style={{marginTop:12}}>
          {options.map((opt) => {
            const isCorrect = locked && opt === q.answer;
            const isWrong = locked && selected === opt && opt !== q.answer;
            const cls = `btn option ${isCorrect ? 'optionCorrect' : ''} ${isWrong ? 'optionWrong' : ''}`;
            return (
              <button key={opt} className={cls} onClick={() => choose(opt)}>
                {opt}
              </button>
            );
          })}
        </div>

        {locked ? (
          <p className="small" style={{marginTop:10}}>
            正确答案：<b>{q.answer}</b>
          </p>
        ) : null}

        {message ? <p className="small" style={{marginTop:10}}>{message}</p> : null}

        <div className="row" style={{marginTop:12}}>
          <button className="btn btnPrimary" onClick={loadNext}>下一题</button>
          <button className="btn" onClick={restart}>重新开始</button>
          <div className="badge">得分：{score} / {Math.max(total, 0)}</div>
        </div>
      </div>

      <div className="card">
        <h2 className="h2">游戏设置（改这里就行）</h2>
        <p className="small">这块是“安全区”：改错也不会把项目弄坏。</p>

        <div className="row" style={{marginTop:10}}>
          <label className="small">年级：</label>
          <select value={level} onChange={e => setLevel(e.target.value)} className="btn">
            {levels.map(lv => <option key={lv} value={lv}>{lv}</option>)}
          </select>
        </div>

        <div className="row" style={{marginTop:10}}>
          <label className="small">主题：</label>
          <select value={topic} onChange={e => setTopic(e.target.value)} className="btn">
            {topics.map(tp => <option key={tp} value={tp}>{tp}</option>)}
          </select>
        </div>

        <div className="row" style={{marginTop:10}}>
          <label className="small">每题秒数：</label>
          <input
            className="btn"
            type="number"
            min={5}
            max={60}
            value={secondsPerQ}
            onChange={e => setSecondsPerQ(Number(e.target.value) || DEFAULT_TIME)}
            style={{width:120}}
          />
        </div>

        <div className="row" style={{marginTop:10}}>
          <label className="small">AI 出题：</label>
          <button className="btn" onClick={() => setAiMode(v => !v)}>
            {aiMode ? '已开启（需要Key）' : '未开启'}
          </button>
        </div>

        <div className="row" style={{marginTop:12}}>
          <button className="btn btnPrimary" onClick={applyFilters}>应用设置并重开</button>
          <a className="btn btnGhost" href="/start">不会改？看新手指南</a>
        </div>

        <div style={{marginTop:12}}>
          <p className="small"><b>中学生能独立跑通的关键：</b></p>
          <ul className="small">
            <li>改题库：只改 <code>src/data/questionBank.js</code></li>
            <li>加新功能：只加在 <code>src/lib/</code> 或 <code>src/components/</code></li>
            <li>页面只“拼装”：放在 <code>src/app/</code></li>
          </ul>
        </div>
      </div>
    </div>
  );
}
