'use client';

import { useEffect, useState } from 'react';

function todayKey() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export default function CheckIn() {
  const [streak, setStreak] = useState(0);
  const [last, setLast] = useState('');
  const [msg, setMsg] = useState('');

  useEffect(() => {
    const s = Number(localStorage.getItem('checkin_streak') || '0');
    const l = localStorage.getItem('checkin_last') || '';
    setStreak(s);
    setLast(l);
  }, []);

  function checkIn() {
    const t = todayKey();
    if (last === t) {
      setMsg('今天已经打过卡啦 ✅');
      return;
    }
    // 简化：只要不是今天，就 streak +1（孩子能理解）；
    // 进阶任务：判断是否连续。
    const next = streak + 1;
    setStreak(next);
    setLast(t);
    localStorage.setItem('checkin_streak', String(next));
    localStorage.setItem('checkin_last', t);
    setMsg(`打卡成功！连续天数：${next}`);
  }

  function reset() {
    setStreak(0);
    setLast('');
    localStorage.removeItem('checkin_streak');
    localStorage.removeItem('checkin_last');
    setMsg('已清空记录。');
  }

  const badge = streak >= 10 ? '🏆 10天达人' : streak >= 5 ? '🥇 5天坚持' : streak >= 1 ? '🌱 新手起步' : '🙂 还没开始';

  return (
    <div className="card">
      <h1 className="h1">项目2：学习打卡</h1>
      <p className="small">这个项目展示“用代码解决真实生活问题”。家长能看到：习惯养成 + 数据记录。</p>

      <div className="row" style={{marginTop:12}}>
        <div className="badge">连续天数：{streak}</div>
        <div className="badge">徽章：{badge}</div>
        <div className="badge">最后打卡：{last || '暂无'}</div>
      </div>

      <div className="row" style={{marginTop:12}}>
        <button className="btn btnPrimary" onClick={checkIn}>今天打卡</button>
        <button className="btn" onClick={reset}>清空</button>
      </div>

      {msg ? <p className="small" style={{marginTop:10}}>{msg}</p> : null}

      <div style={{marginTop:14}}>
        <h2 className="h2">进阶挑战（用 AI 帮你写）</h2>
        <ul className="small">
          <li>做成“连续打卡”：如果隔天没打卡就重置 streak。</li>
          <li>让孩子自己设计 3 个徽章规则（比如 3天、7天、21天）。</li>
          <li>加一个“打卡日历”：显示本月哪些天打过卡。</li>
        </ul>
      </div>
    </div>
  );
}
