'use client';

import { useEffect, useMemo, useState } from 'react';

const seed = [
  { id:'quiz', name:'答题小游戏', skills:['逻辑','计时','反馈','题库'], evidence:'得分/计时可运行' },
  { id:'checkin', name:'学习打卡', skills:['数据记录','习惯养成','本地存储'], evidence:'连续天数 + 徽章' },
  { id:'assistant', name:'AI 学习助手', skills:['提示词','迭代','表达'], evidence:'生成高质量提示词' }
];

export default function Portfolio() {
  const [notes, setNotes] = useState('');

  useEffect(() => {
    setNotes(localStorage.getItem('portfolio_notes') || '');
  }, []);

  function save() {
    localStorage.setItem('portfolio_notes', notes);
  }

  const md = useMemo(() => {
    return `# 我的 AI 作品集\n\n## 我完成的项目\n\n${seed.map(p => `- **${p.name}**（证据：${p.evidence}）\n  - 我学会了：${p.skills.join('、')}`).join('\n\n')}\n\n## 我的迭代记录\n\n${notes || '（在右侧写：我改了什么？为什么改？结果更好吗？）'}\n`;
  }, [notes]);

  return (
    <div className="grid" style={{marginTop:12}}>
      <div className="card">
        <h1 className="h1">作品集（可直接复制）</h1>
        <p className="small">家长看得见的成果：项目 + 迭代记录 + 反思。升学/竞赛也更有说服力。</p>
        <pre className="card" style={{whiteSpace:'pre-wrap', margin:0}}>{md}</pre>
      </div>

      <div className="card">
        <h2 className="h2">写 3 句话就够了</h2>
        <p className="small">按这个模板写（越简单越好）：</p>
        <ul className="small">
          <li>我做了什么改动？</li>
          <li>我为什么要改？（遇到什么问题）</li>
          <li>改完变好了什么？（证据）</li>
        </ul>

        <textarea
          className="btn"
          value={notes}
          onChange={e => setNotes(e.target.value)}
          rows={10}
          style={{width:'100%', resize:'vertical'}}
          placeholder={'例：\n1) 我把倒计时从 10s 改成 15s，因为太快会紧张。\n2) 我增加了“答错高亮正确答案”，因为我想立刻知道正确选项。\n3) 现在我能更快复盘错题，得分提高了。'}
        />

        <div className="row" style={{marginTop:12}}>
          <button className="btn btnPrimary" onClick={save}>保存</button>
          <span className="small">（保存在浏览器本地，不会上网）</span>
        </div>
      </div>
    </div>
  );
}
