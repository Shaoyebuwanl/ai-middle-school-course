'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';

export default function Nav() {
  const [theme, setTheme] = useState('dark');

  useEffect(() => {
    const saved = typeof window !== 'undefined' ? localStorage.getItem('theme') : null;
    const t = saved || 'dark';
    setTheme(t);
    document.documentElement.setAttribute('data-theme', t);
  }, []);

  function toggle() {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);
  }

  return (
    <div className="nav">
      <div className="navLeft">
        <Link href="/" className="badge">AI Project Lab</Link>
        <Link href="/quiz" className="badge">答题游戏</Link>
        <Link href="/projects" className="badge">项目</Link>
        <Link href="/portfolio" className="badge">作品集</Link>
      </div>
      <div className="row">
        <button className="btn btnGhost" onClick={toggle}>主题：{theme === 'dark' ? '深色' : '浅色'}</button>
      </div>
    </div>
  );
}
