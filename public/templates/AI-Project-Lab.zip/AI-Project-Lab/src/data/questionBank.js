// ⭐只改这里：新增/替换题库
// 规则：每题必须有 question / options(4个) / answer(必须等于 options 其中一个) / hint(可选)

export const questionBank = [
  {
    id: 'm1',
    level: '小学',
    topic: '数学',
    question: '3 + 5 = ?',
    options: ['6', '7', '8', '9'],
    answer: '8',
    hint: '把 3 和 5 凑在一起。'
  },
  {
    id: 'l1',
    level: '小学',
    topic: 'AI思维',
    question: 'AI 最像下面哪一种？',
    options: ['会算概率的工具', '有感情的人', '会做梦的大脑', '永远不会出错的老师'],
    answer: '会算概率的工具',
    hint: 'AI 主要靠数据和规则来预测。'
  },
  {
    id: 'c1',
    level: '初中',
    topic: '编程逻辑',
    question: '下面哪个更像“迭代”？',
    options: ['写完一次就不改了', '每次根据反馈改一点点', '只会复制粘贴', '把问题跳过'],
    answer: '每次根据反馈改一点点',
    hint: '迭代=循环改进。'
  },
  {
    id: 'c2',
    level: '初中',
    topic: '编程逻辑',
    question: 'if (x > 10) 这句最像什么？',
    options: ['条件判断', '循环', '数组', '函数返回'],
    answer: '条件判断'
  },
  {
    id: 'a1',
    level: '初中',
    topic: 'AI工具',
    question: '用 AI 帮你写代码时，最好的做法是？',
    options: ['直接复制不看', '让 AI 解释代码 + 自己小改', '只让 AI 写，不做测试', '看到报错就放弃'],
    answer: '让 AI 解释代码 + 自己小改'
  }
];

export const topics = ['数学', 'AI思维', '编程逻辑', 'AI工具'];
export const levels = ['小学', '初中'];
