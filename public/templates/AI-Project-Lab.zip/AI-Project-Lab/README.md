# AI Project Lab（中小学生可独立跑通）

这个项目是为**中小学生（尤其小学高年级/初中）**设计的：
- 不用写超长代码，也能做出可运行作品
- 能练到“编程逻辑 + 迭代思维 + 用 AI 工具提高效率”
- 家长能看到成果：可运行项目 + 作品集（带迭代记录）

## 1) 一键运行（本地）

```bash
npm install
npm run dev
```
打开：`http://localhost:3000`

## 2) 改哪里（0基础必看）

- ✅ 改题库：`src/data/questionBank.js`
- ✅ 加功能（逻辑）：`src/lib/...`
- ✅ 加功能（界面）：`src/components/...`
- ⚠️ 页面拼装：`src/app/...`

## 3) 可选：开启 AI 出题

1. 复制 `.env.example` → `.env.local`
2. 填 `OPENAI_API_KEY`
3. 重启 `npm run dev`
4. 答题页右侧开启“AI 出题”

## 4) 部署到 Vercel

- 把代码 push 到 GitHub
- Vercel 导入项目
- 如果要 AI 出题，记得在 Vercel 项目里添加环境变量 `OPENAI_API_KEY`

---

> 你提到的“答案选项空白”问题：此项目已通过**强制 JSON 结构 + validate**解决。
