// ✅ 新手只需要改 2 个地方：
// 1) index.html 里改标题/描述
// 2) 下面的 QUESTIONS 题库（复制 AI 生成的题目进来即可）
//
// ❗不要双击运行 app.js（会弹 Windows Script Host 报错）
// 正确做法：用 VS Code/记事本打开编辑。

// =======================
// 1) 你可以改的设置
// =======================
var QUESTION_TIME = 10; // 每题倒计时（秒）

// =======================
// 2) 题库（你主要改这里）
// 支持两种格式：
// A. { q, choices, answer }  （推荐）
// B. { question, options, answer }（AI 常给的格式）
// answer 支持：正确选项的文字，或者 "A"/"B"/"C"/"D"
// =======================
var QUESTIONS = [
  {
    q: "法国的首都是哪座城市？",
    choices: ["伦敦", "巴黎", "柏林", "罗马"],
    answer: "巴黎"
  },
  {
    question: "地球绕太阳转一圈大约需要多久？",
    options: ["1天", "1周", "1个月", "1年"],
    answer: "D"
  }
];

// =======================
// 3) 下面是程序逻辑（不建议新手改）
// =======================
var state = {
  score: 0,
  current: null,
  locked: false,
  timeLeft: 0,
  timerId: null
};

function $(id){ return document.getElementById(id); }

function pickRandom(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

// choices 支持：字符串数组 或 对象数组
function toChoiceMeta(choice, idx){
  var key = 'ABCD'[idx] || '';
  if (typeof choice === 'string') {
    return { key: key, text: choice, display: key + ". " + choice };
  }
  if (choice && typeof choice === 'object') {
    var k = (choice.key || key);
    var t = (choice.text || choice.value || "");
    return { key: k, text: t, display: k + ". " + t };
  }
  return { key: key, text: "", display: key + ". " };
}

function normalizeQuestion(raw){
  if (!raw) return null;

  var q = (raw.q || raw.question || raw.text || "").toString().trim();
  var arr = raw.choices || raw.options || raw.choice || raw.answers || [];
  if (!Array.isArray(arr)) arr = [];

  var choices = [];
  for (var i=0; i<Math.min(arr.length,4); i++){
    choices.push(toChoiceMeta(arr[i], i));
  }

  // answer：可能是 A/B/C/D 或者文本
  var a = (raw.answer != null ? String(raw.answer).trim() : "");
  var answerKey = "";
  var answerText = "";

  if (/^[A-D]$/i.test(a)) {
    answerKey = a.toUpperCase();
    var idx = 'ABCD'.indexOf(answerKey);
    answerText = choices[idx] ? choices[idx].text : "";
  } else {
    answerText = a;
    // 如果给的是文本，尝试推回 key
    for (var j=0;j<choices.length;j++){
      if (choices[j].text === answerText) { answerKey = choices[j].key; break; }
    }
  }

  return { q: q, choices: choices, answerKey: answerKey, answerText: answerText };
}

function setScore(n){ state.score = n; $("score").textContent = String(n); }

function stopTimer(){
  if (state.timerId) clearInterval(state.timerId);
  state.timerId = null;
}

function startTimer(){
  stopTimer();
  state.timeLeft = QUESTION_TIME;
  updateTimerUI();

  state.timerId = setInterval(function(){
    state.timeLeft -= 1;
    updateTimerUI();
    if (state.timeLeft <= 0){
      stopTimer();
      onTimeUp();
    }
  }, 1000);
}

function updateTimerUI(){
  $("timer").textContent = String(Math.max(state.timeLeft,0));
  // 进度条
  var pct = (state.timeLeft / QUESTION_TIME) * 100;
  $("barFill").style.width = Math.max(0, Math.min(100, pct)) + "%";

  // ≤ 3 秒闪烁
  if (state.timeLeft <= 3) {
    $("timer").classList.add("blink");
  } else {
    $("timer").classList.remove("blink");
  }
}

function renderQuestion(item){
  state.current = item;
  state.locked = false;

  $("question").textContent = item.q || "(题目为空，请检查题库格式)";
  $("result").textContent = "";
  $("result").className = "result";

  var wrap = $("choices");
  wrap.innerHTML = "";

  for (var i=0;i<item.choices.length;i++){
    var meta = item.choices[i];
    var btn = document.createElement("button");
    btn.className = "choice";
    btn.textContent = meta.display;
    btn.dataset.key = meta.key;
    btn.dataset.text = meta.text;
    btn.onclick = function(){
      if (state.locked) return;
      onChoose(this.dataset.key, this.dataset.text, this);
    };
    wrap.appendChild(btn);
  }

  $("nextBtn").disabled = true;
  $("restartBtn").disabled = false;

  startTimer();
}

function lockChoices(){
  state.locked = true;
  var buttons = $("choices").querySelectorAll("button.choice");
  buttons.forEach(function(b){ b.disabled = true; });
}

function highlightAnswer(selectedKey){
  var buttons = $("choices").querySelectorAll("button.choice");
  buttons.forEach(function(b){
    var k = b.dataset.key;
    if (k === state.current.answerKey || b.dataset.text === state.current.answerText) {
      b.classList.add("good");
    }
    if (selectedKey && k === selectedKey && k !== state.current.answerKey) {
      b.classList.add("bad");
    }
  });
}

function onChoose(key, text){
  stopTimer();
  lockChoices();

  var correct = false;
  if (state.current.answerKey) {
    correct = (key === state.current.answerKey);
  } else {
    correct = (text === state.current.answerText);
  }

  if (correct){
    setScore(state.score + 1);
    $("result").textContent = "✅ 正确！";
    $("result").classList.add("good");
  } else {
    $("result").textContent = "❌ 错了。正确答案是：" + (state.current.answerKey ? (state.current.answerKey + ". " + state.current.answerText) : state.current.answerText);
    $("result").classList.add("bad");
  }

  highlightAnswer(key);
  $("nextBtn").disabled = false;
}

function onTimeUp(){
  if (state.locked) return;
  lockChoices();
  $("result").textContent = "⏰ 时间到！正确答案是：" + (state.current.answerKey ? (state.current.answerKey + ". " + state.current.answerText) : state.current.answerText);
  $("result").classList.add("bad");
  highlightAnswer(""); // 只高亮正确答案
  $("nextBtn").disabled = false;
}

function nextQuestion(){
  var raw = pickRandom(QUESTIONS);
  var q = normalizeQuestion(raw);
  if (!q || q.choices.length === 0){
    $("question").textContent = "题库格式不对：请确保每题有 4 个选项（choices/options）";
    $("choices").innerHTML = "";
    $("result").textContent = "";
    $("nextBtn").disabled = true;
    return;
  }
  renderQuestion(q);
}

function resetAll(){
  stopTimer();
  setScore(0);
  state.current = null;
  state.locked = false;
  state.timeLeft = 0;
  $("timer").textContent = "--";
  $("barFill").style.width = "0%";
  $("question").textContent = "点击「开始」进入第一题。";
  $("choices").innerHTML = "";
  $("result").textContent = "";
  $("result").className = "result";
  $("nextBtn").disabled = true;
  $("restartBtn").disabled = true;
}

$("startBtn").onclick = function(){
  $("restartBtn").disabled = false;
  nextQuestion();
};

$("nextBtn").onclick = function(){
  nextQuestion();
};

$("restartBtn").onclick = function(){
  resetAll();
  nextQuestion();
};

resetAll();
