// 提示：不要双击运行 app.js（会弹 Windows Script Host 报错）。用 VS Code/记事本打开编辑即可。
// 一个最小可运行的“题目小应用”示例
// 你可以让 AI 帮你：生成更多题目，然后复制到 questions 数组里。

var questions = [
  {
    q: "法国的首都是哪座城市？",
    choices: ["伦敦", "巴黎", "柏林", "罗马"],
    answer: "巴黎"
  },
  {
    q: "地球绕太阳转一圈大约需要多久？",
    choices: ["1天", "1周", "1个月", "1年"],
    answer: "1年"
  }
];

var state = { current: null };

function $(id){ return document.getElementById(id); }

function pickRandom(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

// 兼容两种题目格式：
// 1) choices 是字符串数组：["北京","上海",...], answer 写“正确选项内容”
// 2) choices 是对象数组：[{key:"A",text:"北京"},...], answer 写 "A"/"B"/... 或写 text
function getChoiceMeta(choice, idx){
  if (typeof choice === 'string') {
    return { key: 'ABCD'[idx] || '', text: choice, display: choice };
  }
  if (choice && typeof choice === 'object') {
    var k = choice.key || ('ABCD'[idx] || '');
    var t = choice.text || choice.value || '';
    var display = (k ? (k + '. ') : '') + t;
    return { key: k, text: t, display: display };
  }
  return { key: 'ABCD'[idx] || '', text: '', display: '' };
}

function normalizeAnswer(item){
  var a = (item && item.answer != null) ? String(item.answer).trim() : '';
  // 如果 answer 是 A/B/C/D，映射到对应选项文本
  if (/^[A-D]$/i.test(a) && item && Array.isArray(item.choices)) {
    var idx = 'ABCD'.indexOf(a.toUpperCase());
    var meta = getChoiceMeta(item.choices[idx], idx);
    return { key: a.toUpperCase(), text: meta.text };
  }
  // 否则认为 answer 是“正确选项内容”
  return { key: '', text: a };
}


function renderQuestion(item){
  state.current = item;
  $("question").textContent = item.q;
  $("result").textContent = "";
  var wrap = $("choices");
  wrap.innerHTML = "";
  for (var i=0;i<item.choices.length;i++){
    var c = item.choices[i];
    var btn = document.createElement("button");
    btn.className = "choice";
    var meta = getChoiceMeta(c, i);
    btn.textContent = meta.display;
    btn.dataset.choiceKey = meta.key;
    btn.dataset.choiceText = meta.text;
    btn.onclick = function(){
      var selected = this.textContent;
      if (selected === state.current.answer){
        $("result").textContent = "✅ 正确！";
      } else {
        $("result").textContent = "❌ 再试一次。正确答案是：" + state.current.answer;
      }
    };
    wrap.appendChild(btn);
  }
}

function reset(){
  state.current = null;
  $("question").textContent = "点击按钮生成一道选择题（示例）。";
  $("choices").innerHTML = "";
  $("result").textContent = "";
}

$("genBtn").onclick = function(){
  renderQuestion(pickRandom(questions));
};

$("resetBtn").onclick = reset;

reset();
