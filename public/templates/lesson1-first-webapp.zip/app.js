// 一个最小可运行的“题目小应用”示例
// 你可以让 AI 帮你：生成更多题目，然后复制到 questions 数组里。

var questions = [
  {
    q: "法国的首都是哪座城市？",
    choices: ["伦敦", "巴黎", "柏林", "罗马"],
    answer: "巴黎"
  },
  {
    q: "地球绕太阳转一圈大约需要多久？",
    choices: ["1天", "1周", "1个月", "1年"],
    answer: "1年"
  }
];

var state = { current: null };

function $(id){ return document.getElementById(id); }

function pickRandom(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function renderQuestion(item){
  state.current = item;
  $("question").textContent = item.q;
  $("result").textContent = "";
  var wrap = $("choices");
  wrap.innerHTML = "";
  for (var i=0;i<item.choices.length;i++){
    var c = item.choices[i];
    var btn = document.createElement("button");
    btn.className = "choice";
    btn.textContent = c;
    btn.onclick = function(){
      var selected = this.textContent;
      if (selected === state.current.answer){
        $("result").textContent = "✅ 正确！";
      } else {
        $("result").textContent = "❌ 再试一次。正确答案是：" + state.current.answer;
      }
    };
    wrap.appendChild(btn);
  }
}

function reset(){
  state.current = null;
  $("question").textContent = "点击按钮生成一道选择题（示例）。";
  $("choices").innerHTML = "";
  $("result").textContent = "";
}

$("genBtn").onclick = function(){
  renderQuestion(pickRandom(questions));
};

$("resetBtn").onclick = reset;

reset();
