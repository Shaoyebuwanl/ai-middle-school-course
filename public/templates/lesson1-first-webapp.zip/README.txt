【第1课模板使用说明（给学生）】

1) 解压 zip 后，你会看到：
   - index.html（用浏览器打开）
   - style.css（改样式）
   - app.js（改题目）

2) 重要：不要双击 app.js！
   双击会被 Windows 当成“脚本”运行，弹出 Windows Script Host 报错。
   正确做法：右键 app.js → 用“记事本”或“VS Code”打开，修改后保存。

3) 修改题目：
   在 app.js 里找到 var questions = [ ... ] ，把里面的示例题替换成你自己的题目。

4) 保存并刷新：
   保存 app.js 后，回到浏览器按 Ctrl + R 刷新 index.html，再点“Generate questions”测试。
